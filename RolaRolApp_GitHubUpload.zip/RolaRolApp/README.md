# RolaRol Alarm App
A custom alarm app that plays audio from a URL.